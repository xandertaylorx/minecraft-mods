// Shared uniforms and helpers. Pure math only, no texture reads.

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform float far;
uniform float near;
uniform float nightVision;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
uniform int frameCounter;

// ---------------- Temporal anti-aliasing ----------------
// Each frame the whole picture is nudged by a sub-pixel amount (an 8-step Halton(2,3) pattern).
// The TAA pass blends frames together, so edges and fine texture detail get averaged smooth.
vec2 taaOffset() {
	const vec2 seq[8] = vec2[8](
		vec2( 0.000, -0.167), vec2(-0.250,  0.167), vec2( 0.250, -0.389), vec2(-0.375, -0.056),
		vec2( 0.125,  0.278), vec2(-0.125, -0.278), vec2( 0.375,  0.056), vec2(-0.438,  0.389));
	return seq[frameCounter & 7];
}
// Apply to a clip-space vertex position (no-op when TAA is off).
vec4 taaJitter(vec4 clip) {
#ifdef TAA
	clip.xy += taaOffset() * 2.0 / vec2(viewWidth, viewHeight) * clip.w;
#endif
	return clip;
}
// Per-frame offset for noise patterns, so TAA averages filter noise away (shadows, AO).
float frameNoiseShift() {
#ifdef TAA
	return float(frameCounter & 15) * 0.6180339;
#else
	return 0.0;
#endif
}

// Block IDs from block.properties
#define ID_PLANT      10001
#define ID_LEAVES     10002
#define ID_PLANT_FULL 10004
#define ID_WATER      10010
#define ID_EMISSIVE   10020
#define ID_LAVA       10021

const vec3 TORCH_COLOR = vec3(1.0, 0.64, 0.32);

// True if the depth at screen point uv is sky or beyond render distance (e.g. clouds).
// Clouds write depth but shouldn't block lens flare or sun rays. Uses the real projection, so it's exact.
bool isSkyAt(vec2 uv, float d) {
	if (d >= 0.99999) return true;
	vec4 v = gbufferProjectionInverse * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
	return -v.z / v.w > far * 0.98;
}

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 toLinear(vec3 c) { return c * c * (c * 0.2 + 0.8); }   // cheap ~gamma 2.2

// Sky light reaching a face depends on which way it points: tops see the whole sky, sides half of it,
// undersides only bounce light. Keeps shaded areas from looking flat. 1.0 top, 0.78 N/S, 0.70 E/W, 0.52 bottom.
float faceShade(vec3 wn) {
	return 0.76 + 0.24 * wn.y - 0.08 * abs(wn.x) + 0.02 * abs(wn.z);
}

// Sun direction in world space (y = up). Uses the real sun even at night.
vec3 worldSunDir() { return normalize(mat3(gbufferModelViewInverse) * sunPosition); }

// ---------------- Time-of-day colors ----------------
// h = sun height (-1..1). These run per vertex, not per pixel.

// Every ramp below is wide and smooth, so nothing pops when the sun crosses the horizon.
float dayFactor(float h)    { return smoothstep(-0.10, 0.30, h); }
float sunsetFactor(float h) { return 1.0 - smoothstep(0.0, 0.5, abs(h - 0.07)); }
float nightFactor(float h)  { return 1.0 - smoothstep(-0.22, 0.04, h); }
// Dawn: sun low and in the east (+X). Used for morning mist.
float morningFactor(vec3 sunDir) {
	return sunsetFactor(sunDir.y) * smoothstep(-0.1, 0.25, sunDir.x);
}

const vec3 SUN_DAY_COL    = vec3(1.00, 0.96, 0.92) * 1.30;
const vec3 SUN_SUNSET_COL = vec3(1.00, 0.50, 0.18) * 1.75;
const vec3 MOON_COL       = vec3(0.42, 0.60, 0.95) * 0.09;   // cool blue moonlight

// Color of the sun (or moon) as the sky, clouds, sun disc and rays see it. Blends continuously through the horizon.
vec3 celestialColor(float h) {
#if defined NETHER || defined END
	return vec3(0.0);
#else
	vec3 sun = mix(SUN_SUNSET_COL, SUN_DAY_COL, smoothstep(0.08, 0.50, h));
	return mix(MOON_COL, sun, smoothstep(-0.10, 0.06, h)) * (1.0 - rainStrength * 0.8) * SUN_BRIGHTNESS;
#endif
}

// Direct light that shadows are cast from. Iris swaps the shadow light from sun to moon exactly when the sun touches
// the horizon, so BOTH lights have to be zero right there. Fading them out is what keeps sunset and sunrise from
// snapping every shadow to a new direction.
vec3 sunLightColor(float h) {
#if defined NETHER || defined END
	return vec3(0.0);
#else
	vec3 sun = mix(SUN_SUNSET_COL, SUN_DAY_COL, smoothstep(0.08, 0.50, h));
	float sunFade  = smoothstep(0.0, 0.16, h);
	float moonFade = 1.0 - smoothstep(-0.22, 0.0, h);
	return (sun * sunFade + MOON_COL * moonFade) * (1.0 - rainStrength * 0.8) * SUN_BRIGHTNESS;
#endif
}

vec3 ambientColor(float h) {
#ifdef NETHER
	return toLinear(fogColor) * 0.9 + vec3(0.12, 0.05, 0.03);
#elif defined END
	return vec3(0.10, 0.08, 0.16);
#else
	vec3 day      = vec3(0.30, 0.46, 0.86) * 0.92;   // clear blue skylight fills the shade
	vec3 sunset   = vec3(0.50, 0.36, 0.34) * 0.55;
	vec3 twilight = vec3(0.095, 0.115, 0.235);        // blue hour after sunset / before sunrise, bridges day and night
	vec3 night    = vec3(0.018, 0.036, 0.062);        // deep teal-blue moonlit shade
	vec3 c = mix(sunset, day, smoothstep(0.05, 0.40, h));
	c = mix(twilight, c, smoothstep(-0.10, 0.06, h));
	c = mix(night, c, smoothstep(-0.34, -0.06, h));
	c = mix(c, vec3(luma(c)) * 0.75, rainStrength * 0.7);
	return c * AMBIENT_BRIGHTNESS;
#endif
}

// 0 outdoors, 1 deep indoors or in a cave. Reads the sky light at the camera (already smoothed over a few seconds),
// so walking through a door fades fog and exposure instead of popping.
float indoorFactor() {
	return 1.0 - smoothstep(0.05, 0.75, float(eyeBrightnessSmooth.y) / 240.0);
}

// ---------------- Sky ----------------
vec3 skyColor(vec3 dir, vec3 sunDir) {
#ifdef NETHER
	return toLinear(fogColor);
#elif defined END
	return vec3(0.02, 0.012, 0.035);
#else
	float h = sunDir.y;
	float day = dayFactor(h);
	float sunset = sunsetFactor(h);
	float night = nightFactor(h);
	float up = max(dir.y, 0.0);
	float horizon = pow(1.0 - up, 3.0);

	vec3 zenith = mix(vec3(0.003, 0.006, 0.016), vec3(0.07, 0.22, 0.75), day * (1.0 - sunset * 0.6));
	vec3 hor    = mix(vec3(0.012, 0.018, 0.032), vec3(0.40, 0.58, 0.92), day);
	zenith = mix(zenith, vec3(0.30, 0.20, 0.20), sunset * 0.75);  // warm, dusky sky overhead at sunset
	vec3 col = mix(zenith, hor, horizon);

	// Warm sunset band, strongest on the sun's side of the sky
	float sunSide = dot(dir, sunDir) * 0.5 + 0.5;
	vec3 sunsetCol = mix(vec3(0.48, 0.24, 0.16), vec3(1.00, 0.42, 0.07), sunSide * sunSide);
	col = mix(col, sunsetCol, sunset * pow(1.0 - up, 0.6) * (0.65 + 0.35 * sunSide));

	// Deep orange right at the horizon under the sun
	col = mix(col, vec3(1.0, 0.28, 0.04), sunset * pow(1.0 - up, 7.0) * pow(sunSide, 4.0) * 0.85);

	// Dawn is a little paler and pinker than dusk
	col = mix(col, vec3(0.95, 0.62, 0.55) * 0.8, morningFactor(sunDir) * horizon * 0.35);

	// Glow around the sun
	float sd = max(dot(dir, sunDir), 0.0);
	col += celestialColor(h) * (pow(sd, 6.0) * 0.10 + pow(sd, 40.0) * 0.20) * smoothstep(-0.1, 0.05, h) * (1.0 - sunset * 0.5);

	// Night: soft halo around the moon and a faint glow along the horizon
	float md = max(dot(dir, -sunDir), 0.0);
	col += vec3(0.55, 0.62, 0.80) * (pow(md, 24.0) * 0.025 + pow(md, 200.0) * 0.10) * night;
	col += vec3(0.025, 0.03, 0.045) * pow(1.0 - up, 6.0) * night;

	// Below the horizon, fade a little darker
	col *= 1.0 - clamp(-dir.y, 0.0, 1.0) * 0.4;

	col = mix(col, vec3(luma(col)) * vec3(0.85, 0.9, 1.0) * 0.7, rainStrength * 0.85);
	return col;
#endif
}

// ---------------- Atmosphere / fog ----------------
// How thick the air is right now: misty dawns, clear noons, hazy golden dusk, light night mist.
float airDensity(vec3 sunDir) {
	float h = sunDir.y;
	return (1.0 + morningFactor(sunDir) * 1.4 + sunsetFactor(h) * 0.4 + nightFactor(h) * 0.9 + rainStrength * 3.5) * FOG_DENSITY;
}

// How much fog covers something at view-space distance `dist`.
float fogAmount(float dist, vec3 sunDir) {
	if (isEyeInWater == 1) return 1.0 - exp(-dist * 0.07);
	if (isEyeInWater == 2) return 1.0 - exp(-dist * 0.6);
#ifdef NETHER
	float haze = 1.0 - exp(-dist * 0.012 * FOG_DENSITY);
#elif defined END
	float haze = 1.0 - exp(-dist * 0.006 * FOG_DENSITY);
#else
	// Indoors and in caves there is hardly any haze, so rooms stay crisp
	float haze = 1.0 - exp(-dist * 0.0026 * airDensity(sunDir) * mix(1.0, 0.12, indoorFactor()));
#endif
	// Border fog hides the edge of the render distance
	float border = smoothstep(far * 0.72, far, dist);
	return clamp(max(haze, border), 0.0, 1.0);
}

vec3 fogColorFor(vec3 dir, vec3 sunDir) {
	if (isEyeInWater == 1) return vec3(0.02, 0.09, 0.14) * (0.2 + 0.8 * dayFactor(sunDir.y));
	if (isEyeInWater == 2) return vec3(0.9, 0.25, 0.02);
	vec3 c = skyColor(dir, sunDir);
#if !defined NETHER && !defined END
	// Sunlight scattering in the haze: fog glows warm toward the sun
	float sd = max(dot(dir, sunDir), 0.0);
	c += celestialColor(sunDir.y) * pow(sd, 5.0) * 0.30 * dayFactor(sunDir.y + 0.1);
	// Fog in a room or cave is dark, not sky-colored, so it never washes the view out
	c *= mix(1.0, 0.10, indoorFactor());
#endif
	return c;
}
