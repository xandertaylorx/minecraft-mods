#version 330 compatibility
#define FRAGMENT
#include "/program/water.glsl"
