#version 330 compatibility
#define VERTEX
#include "/program/ao.glsl"
